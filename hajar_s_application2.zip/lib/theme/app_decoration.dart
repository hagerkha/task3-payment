import 'package:flutter/material.dart';
import '../core/app_export.dart';

class AppDecoration {
  // Icon decorations
  static BoxDecoration get iconSquareColor => BoxDecoration(
        color: appTheme.deepOrange50,
      );
// White decorations
  static BoxDecoration get white => BoxDecoration(
        color: theme.colorScheme.onPrimaryContainer,
      );
}

class BorderRadiusStyle {
  // Rounded borders
  static BorderRadius get roundedBorder16 => BorderRadius.circular(
        16.h,
      );
}
