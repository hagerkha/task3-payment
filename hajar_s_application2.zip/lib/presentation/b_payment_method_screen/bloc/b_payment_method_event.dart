part of 'b_payment_method_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///BPaymentMethod widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class BPaymentMethodEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the BPaymentMethod widget is first created.
class BPaymentMethodInitialEvent extends BPaymentMethodEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing date

// ignore_for_file: must_be_immutable
class ChangeDateEvent extends BPaymentMethodEvent {
  ChangeDateEvent({required this.date});

  DateTime date;

  @override
  List<Object?> get props => [date];
}
