import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/b_payment_method_model.dart';
part 'b_payment_method_event.dart';
part 'b_payment_method_state.dart';

/// A bloc that manages the state of a BPaymentMethod according to the event that is dispatched to it.
class BPaymentMethodBloc
    extends Bloc<BPaymentMethodEvent, BPaymentMethodState> {
  BPaymentMethodBloc(BPaymentMethodState initialState) : super(initialState) {
    on<BPaymentMethodInitialEvent>(_onInitialize);
    on<ChangeDateEvent>(_changeDate);
  }

  _onInitialize(
    BPaymentMethodInitialEvent event,
    Emitter<BPaymentMethodState> emit,
  ) async {
    emit(
      state.copyWith(
        nameController: TextEditingController(),
        cardNumberEditController: TextEditingController(),
        expiryDateEditController: TextEditingController(),
        cvvEditController: TextEditingController(),
      ),
    );
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.bPasswordSettingScreen,
      );
    });
  }

  _changeDate(
    ChangeDateEvent event,
    Emitter<BPaymentMethodState> emit,
  ) {
    emit(state.copyWith(
        bPaymentMethodModelObj: state.bPaymentMethodModelObj?.copyWith(
      selectedExpiryDateEdit: event.date,
    )));
  }
}
