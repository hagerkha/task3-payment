part of 'b_payment_method_bloc.dart';

/// Represents the state of BPaymentMethod in the application.

// ignore_for_file: must_be_immutable
class BPaymentMethodState extends Equatable {
  BPaymentMethodState(
      {this.nameController,
      this.cardNumberEditController,
      this.expiryDateEditController,
      this.cvvEditController,
      this.bPaymentMethodModelObj});

  TextEditingController? nameController;

  TextEditingController? cardNumberEditController;

  TextEditingController? expiryDateEditController;

  TextEditingController? cvvEditController;

  BPaymentMethodModel? bPaymentMethodModelObj;

  @override
  List<Object?> get props => [
        nameController,
        cardNumberEditController,
        expiryDateEditController,
        cvvEditController,
        bPaymentMethodModelObj
      ];
  BPaymentMethodState copyWith({
    TextEditingController? nameController,
    TextEditingController? cardNumberEditController,
    TextEditingController? expiryDateEditController,
    TextEditingController? cvvEditController,
    BPaymentMethodModel? bPaymentMethodModelObj,
  }) {
    return BPaymentMethodState(
      nameController: nameController ?? this.nameController,
      cardNumberEditController:
          cardNumberEditController ?? this.cardNumberEditController,
      expiryDateEditController:
          expiryDateEditController ?? this.expiryDateEditController,
      cvvEditController: cvvEditController ?? this.cvvEditController,
      bPaymentMethodModelObj:
          bPaymentMethodModelObj ?? this.bPaymentMethodModelObj,
    );
  }
}
