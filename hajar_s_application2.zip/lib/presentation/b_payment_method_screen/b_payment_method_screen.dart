import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import '../../core/app_export.dart';
import '../../core/utils/date_time_utils.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/b_payment_method_bloc.dart';
import 'models/b_payment_method_model.dart';

class BPaymentMethodScreen extends StatelessWidget {
  const BPaymentMethodScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<BPaymentMethodBloc>(
      create: (context) => BPaymentMethodBloc(BPaymentMethodState(
        bPaymentMethodModelObj: BPaymentMethodModel(),
      ))
        ..add(BPaymentMethodInitialEvent()),
      child: BPaymentMethodScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(
                left: 34.h,
                top: 32.h,
                right: 34.h,
              ),
              child: Column(
                children: [
                  _buildCardDetailsStack(context),
                  SizedBox(height: 32.h),
                  _buildCardHolderColumn(context),
                  SizedBox(height: 26.h),
                  _buildCardNumberColumn(context),
                  SizedBox(height: 20.h),
                  _buildExpiryAndCvvRow(context),
                  SizedBox(height: 54.h),
                  _buildSaveCardButton(context),
                  SizedBox(height: 4.h)
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildBottomNavigationRow(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 44.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 26.h),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "lbl_add_card".tr,
      ),
    );
  }

  /// Section Widget
  Widget _buildCardDetailsStack(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Card(
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        margin: EdgeInsets.zero,
        color: appTheme.deepOrange50,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadiusStyle.roundedBorder16,
        ),
        child: Container(
          height: 194.h,
          width: double.maxFinite,
          decoration: BoxDecoration(
            color: appTheme.deepOrange50,
            borderRadius: BorderRadiusStyle.roundedBorder16,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.bottomRight,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 28.h,
                    bottom: 22.h,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "lbl_000_000_000_00".tr,
                        style: CustomTextStyles.titleLargeGray800,
                      ),
                      SizedBox(height: 6.h),
                      SizedBox(
                        width: double.maxFinite,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "msg_card_holder_name".tr,
                                  style: CustomTextStyles.bodyMediumGray800,
                                ),
                                SizedBox(height: 2.h),
                                Text(
                                  "lbl_kathryn_murphy".tr,
                                  style: theme.textTheme.bodyMedium,
                                )
                              ],
                            ),
                            SizedBox(
                              width: 82.h,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "lbl_expiry_date".tr,
                                    style: CustomTextStyles.bodyMediumGray800,
                                  ),
                                  Text(
                                    "lbl_04_28".tr,
                                    style: theme.textTheme.bodyMedium,
                                  )
                                ],
                              ),
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgGrid,
                              height: 26.h,
                              width: 30.h,
                              margin: EdgeInsets.only(right: 16.h),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(
                  top: 16.h,
                  right: 16.h,
                  bottom: 16.h,
                ),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: fs.Svg(
                      ImageConstant.imgGroup8,
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgTelevision,
                      height: 12.h,
                      width: 50.h,
                    ),
                    SizedBox(height: 150.h)
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildName(BuildContext context) {
    return BlocSelector<BPaymentMethodBloc, BPaymentMethodState,
        TextEditingController?>(
      selector: (state) => state.nameController,
      builder: (context, nameController) {
        return CustomTextFormField(
          controller: nameController,
          hintText: "lbl_kathryn_murphy".tr,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 20.h,
            vertical: 10.h,
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCardHolderColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "msg_card_holder_name".tr,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.titleSmall,
          ),
          _buildName(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildCardNumberEdit(BuildContext context) {
    return BlocSelector<BPaymentMethodBloc, BPaymentMethodState,
        TextEditingController?>(
      selector: (state) => state.cardNumberEditController,
      builder: (context, cardNumberEditController) {
        return CustomTextFormField(
          controller: cardNumberEditController,
          hintText: "lbl_000_000_000_67".tr,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 20.h,
            vertical: 10.h,
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCardNumberColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "lbl_card_number".tr,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.titleSmall,
          ),
          _buildCardNumberEdit(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildExpiryDateEdit(BuildContext context) {
    return BlocSelector<BPaymentMethodBloc, BPaymentMethodState,
        TextEditingController?>(
      selector: (state) => state.expiryDateEditController,
      builder: (context, expiryDateEditController) {
        return CustomTextFormField(
          readOnly: true,
          width: 86.h,
          controller: expiryDateEditController,
          hintText: "lbl_04_28".tr,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 20.h,
            vertical: 10.h,
          ),
          onTap: () {
            onTapExpiryDateEdit(context);
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCvvEdit(BuildContext context) {
    return BlocSelector<BPaymentMethodBloc, BPaymentMethodState,
        TextEditingController?>(
      selector: (state) => state.cvvEditController,
      builder: (context, cvvEditController) {
        return CustomTextFormField(
          width: 86.h,
          controller: cvvEditController,
          hintText: "lbl_0000".tr,
          textInputAction: TextInputAction.done,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 20.h,
            vertical: 10.h,
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildExpiryAndCvvRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        children: [
          SizedBox(
            width: 130.h,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "lbl_expiry_date".tr,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleSmall,
                ),
                _buildExpiryDateEdit(context)
              ],
            ),
          ),
          Expanded(
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(left: 42.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 16.h),
                    child: Text(
                      "lbl_cvv".tr,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall,
                    ),
                  ),
                  _buildCvvEdit(context)
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSaveCardButton(BuildContext context) {
    return CustomElevatedButton(
      text: "lbl_save_card".tr,
      margin: EdgeInsets.symmetric(horizontal: 58.h),
    );
  }

  /// Section Widget
  Widget _buildBottomNavigationRow(BuildContext context) {
    return Container(
      height: 42.h,
      padding: EdgeInsets.symmetric(horizontal: 58.h),
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgHome,
            height: 28.h,
            width: 22.h,
            margin: EdgeInsets.only(bottom: 14.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgMegaphone,
            height: 18.h,
            width: 20.h,
            margin: EdgeInsets.only(top: 4.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgCart,
            height: 22.h,
            width: 22.h,
            margin: EdgeInsets.only(top: 2.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgThumbsUp,
            height: 18.h,
            width: 26.h,
            margin: EdgeInsets.only(top: 4.h),
          ),
          Container(
            width: 22.h,
            margin: EdgeInsets.only(top: 2.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgLock,
                  height: 20.h,
                  width: double.maxFinite,
                  margin: EdgeInsets.only(left: 2.h),
                ),
                SizedBox(height: 4.h),
                CustomImageView(
                  imagePath: ImageConstant.imgLine3,
                  height: 1.h,
                  width: double.maxFinite,
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Navigates to the previous screen.
  onTapArrowleftone(BuildContext context) {
    NavigatorService.goBack();
  }

  /// Displays a date picker dialog and updates the selected date in the
  /// current [bPaymentMethodModelObj] object if the user selects a valid date.
  ///
  /// This function returns a `Future` that completes with `void`.
  Future<void> onTapExpiryDateEdit(BuildContext context) async {
    var initialState = BlocProvider.of<BPaymentMethodBloc>(context).state;
    DateTime? dateTime = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1970),
        lastDate: DateTime(
            DateTime.now().year, DateTime.now().month, DateTime.now().day));
    if (dateTime != null) {
      context.read<BPaymentMethodBloc>().add(ChangeDateEvent(date: dateTime));
      initialState.expiryDateEditController?.text =
          dateTime.format(pattern: dateTimeFormatPattern);
    }
  }
}
