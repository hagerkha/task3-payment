import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [b_payment_method_screen],
/// and is typically used to hold data that is passed between different parts of the application.

// ignore_for_file: must_be_immutable
class BPaymentMethodModel extends Equatable {
  BPaymentMethodModel(
      {this.selectedExpiryDateEdit, this.expiryDateEdit = "\"\""}) {
    selectedExpiryDateEdit = selectedExpiryDateEdit ?? DateTime.now();
  }

  DateTime? selectedExpiryDateEdit;

  String expiryDateEdit;

  BPaymentMethodModel copyWith({
    DateTime? selectedExpiryDateEdit,
    String? expiryDateEdit,
  }) {
    return BPaymentMethodModel(
      selectedExpiryDateEdit:
          selectedExpiryDateEdit ?? this.selectedExpiryDateEdit,
      expiryDateEdit: expiryDateEdit ?? this.expiryDateEdit,
    );
  }

  @override
  List<Object?> get props => [selectedExpiryDateEdit, expiryDateEdit];
}
