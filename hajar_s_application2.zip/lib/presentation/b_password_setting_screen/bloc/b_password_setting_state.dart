part of 'b_password_setting_bloc.dart';

/// Represents the state of BPasswordSetting in the application.

// ignore_for_file: must_be_immutable
class BPasswordSettingState extends Equatable {
  BPasswordSettingState(
      {this.passwordtwoController,
      this.newPasswordSectionController,
      this.confirmNewPasswordSectionController,
      this.isShowPassword = true,
      this.isShowPassword1 = true,
      this.isShowPassword2 = true,
      this.bPasswordSettingModelObj});

  TextEditingController? passwordtwoController;

  TextEditingController? newPasswordSectionController;

  TextEditingController? confirmNewPasswordSectionController;

  BPasswordSettingModel? bPasswordSettingModelObj;

  bool isShowPassword;

  bool isShowPassword1;

  bool isShowPassword2;

  @override
  List<Object?> get props => [
        passwordtwoController,
        newPasswordSectionController,
        confirmNewPasswordSectionController,
        isShowPassword,
        isShowPassword1,
        isShowPassword2,
        bPasswordSettingModelObj
      ];
  BPasswordSettingState copyWith({
    TextEditingController? passwordtwoController,
    TextEditingController? newPasswordSectionController,
    TextEditingController? confirmNewPasswordSectionController,
    bool? isShowPassword,
    bool? isShowPassword1,
    bool? isShowPassword2,
    BPasswordSettingModel? bPasswordSettingModelObj,
  }) {
    return BPasswordSettingState(
      passwordtwoController:
          passwordtwoController ?? this.passwordtwoController,
      newPasswordSectionController:
          newPasswordSectionController ?? this.newPasswordSectionController,
      confirmNewPasswordSectionController:
          confirmNewPasswordSectionController ??
              this.confirmNewPasswordSectionController,
      isShowPassword: isShowPassword ?? this.isShowPassword,
      isShowPassword1: isShowPassword1 ?? this.isShowPassword1,
      isShowPassword2: isShowPassword2 ?? this.isShowPassword2,
      bPasswordSettingModelObj:
          bPasswordSettingModelObj ?? this.bPasswordSettingModelObj,
    );
  }
}
