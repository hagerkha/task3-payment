part of 'b_password_setting_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///BPasswordSetting widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class BPasswordSettingEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the BPasswordSetting widget is first created.
class BPasswordSettingInitialEvent extends BPasswordSettingEvent {
  @override
  List<Object?> get props => [];
}

///Event for changing password visibility

// ignore_for_file: must_be_immutable
class ChangePasswordVisibilityEvent extends BPasswordSettingEvent {
  ChangePasswordVisibilityEvent({required this.value});

  bool value;

  @override
  List<Object?> get props => [value];
}

///Event for changing password visibility

// ignore_for_file: must_be_immutable
class ChangePasswordVisibilityEvent1 extends BPasswordSettingEvent {
  ChangePasswordVisibilityEvent1({required this.value});

  bool value;

  @override
  List<Object?> get props => [value];
}

///Event for changing password visibility

// ignore_for_file: must_be_immutable
class ChangePasswordVisibilityEvent2 extends BPasswordSettingEvent {
  ChangePasswordVisibilityEvent2({required this.value});

  bool value;

  @override
  List<Object?> get props => [value];
}
