import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../models/b_password_setting_model.dart';
part 'b_password_setting_event.dart';
part 'b_password_setting_state.dart';

/// A bloc that manages the state of a BPasswordSetting according to the event that is dispatched to it.
class BPasswordSettingBloc
    extends Bloc<BPasswordSettingEvent, BPasswordSettingState> {
  BPasswordSettingBloc(BPasswordSettingState initialState)
      : super(initialState) {
    on<BPasswordSettingInitialEvent>(_onInitialize);
    on<ChangePasswordVisibilityEvent>(_changePasswordVisibility);
    on<ChangePasswordVisibilityEvent1>(_changePasswordVisibility1);
    on<ChangePasswordVisibilityEvent2>(_changePasswordVisibility2);
  }

  _changePasswordVisibility(
    ChangePasswordVisibilityEvent event,
    Emitter<BPasswordSettingState> emit,
  ) {
    emit(state.copyWith(
      isShowPassword: event.value,
    ));
  }

  _changePasswordVisibility1(
    ChangePasswordVisibilityEvent1 event,
    Emitter<BPasswordSettingState> emit,
  ) {
    emit(state.copyWith(
      isShowPassword1: event.value,
    ));
  }

  _changePasswordVisibility2(
    ChangePasswordVisibilityEvent2 event,
    Emitter<BPasswordSettingState> emit,
  ) {
    emit(state.copyWith(
      isShowPassword2: event.value,
    ));
  }

  _onInitialize(
    BPasswordSettingInitialEvent event,
    Emitter<BPasswordSettingState> emit,
  ) async {
    emit(
      state.copyWith(
        passwordtwoController: TextEditingController(),
        newPasswordSectionController: TextEditingController(),
        confirmNewPasswordSectionController: TextEditingController(),
        isShowPassword: true,
        isShowPassword1: true,
        isShowPassword2: true,
      ),
    );
  }
}
