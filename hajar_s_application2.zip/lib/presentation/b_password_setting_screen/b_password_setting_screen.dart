import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/b_password_setting_bloc.dart';
import 'models/b_password_setting_model.dart';

class BPasswordSettingScreen extends StatelessWidget {
  const BPasswordSettingScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<BPasswordSettingBloc>(
      create: (context) => BPasswordSettingBloc(BPasswordSettingState(
        bPasswordSettingModelObj: BPasswordSettingModel(),
      ))
        ..add(BPasswordSettingInitialEvent()),
      child: BPasswordSettingScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 30.h,
            top: 88.h,
            right: 30.h,
          ),
          child: Column(
            children: [
              _buildCurrentPasswordSection(context),
              SizedBox(height: 12.h),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 24.h),
                  child: Text(
                    "msg_forgot_password".tr,
                    style: CustomTextStyles.bodyMediumPrimary,
                  ),
                ),
              ),
              SizedBox(height: 20.h),
              _buildColumnnewpasswo(context),
              SizedBox(height: 16.h),
              _buildColumnconfirmne(context),
              SizedBox(height: 52.h),
              _buildChangePasswordButton(context),
              SizedBox(height: 4.h)
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomNavigation(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 44.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 26.h),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "msg_password_settings".tr,
      ),
    );
  }

  /// Section Widget
  Widget _buildPasswordtwo(BuildContext context) {
    return BlocBuilder<BPasswordSettingBloc, BPasswordSettingState>(
      builder: (context, state) {
        return CustomTextFormField(
          controller: state.passwordtwoController,
          suffix: InkWell(
            onTap: () {
              context.read<BPasswordSettingBloc>().add(
                  ChangePasswordVisibilityEvent(value: !state.isShowPassword));
            },
            child: Container(
              margin: EdgeInsets.fromLTRB(16.h, 10.h, 20.h, 10.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgEye,
                height: 20.h,
                width: 24.h,
                fit: BoxFit.contain,
              ),
            ),
          ),
          suffixConstraints: BoxConstraints(
            maxHeight: 40.h,
          ),
          obscureText: state.isShowPassword,
          contentPadding: EdgeInsets.fromLTRB(12.h, 10.h, 20.h, 10.h),
          borderDecoration: TextFormFieldStyleHelper.fillDeepOrangeTL18,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCurrentPasswordSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 2.h),
            child: Text(
              "msg_current_password".tr,
              style: CustomTextStyles.titleSmallPrimaryContainer,
            ),
          ),
          SizedBox(height: 2.h),
          _buildPasswordtwo(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNewPasswordSection(BuildContext context) {
    return BlocBuilder<BPasswordSettingBloc, BPasswordSettingState>(
      builder: (context, state) {
        return CustomTextFormField(
          controller: state.newPasswordSectionController,
          suffix: InkWell(
            onTap: () {
              context.read<BPasswordSettingBloc>().add(
                  ChangePasswordVisibilityEvent1(
                      value: !state.isShowPassword1));
            },
            child: Container(
              margin: EdgeInsets.fromLTRB(16.h, 10.h, 20.h, 10.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgEye,
                height: 20.h,
                width: 24.h,
                fit: BoxFit.contain,
              ),
            ),
          ),
          suffixConstraints: BoxConstraints(
            maxHeight: 40.h,
          ),
          obscureText: state.isShowPassword1,
          contentPadding: EdgeInsets.fromLTRB(12.h, 10.h, 20.h, 10.h),
          borderDecoration: TextFormFieldStyleHelper.fillDeepOrangeTL18,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildColumnnewpasswo(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 2.h),
            child: Text(
              "lbl_new_password".tr,
              style: CustomTextStyles.titleSmallPrimaryContainer,
            ),
          ),
          SizedBox(height: 2.h),
          _buildNewPasswordSection(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildConfirmNewPasswordSection(BuildContext context) {
    return BlocBuilder<BPasswordSettingBloc, BPasswordSettingState>(
      builder: (context, state) {
        return CustomTextFormField(
          controller: state.confirmNewPasswordSectionController,
          textInputAction: TextInputAction.done,
          suffix: InkWell(
            onTap: () {
              context.read<BPasswordSettingBloc>().add(
                  ChangePasswordVisibilityEvent2(
                      value: !state.isShowPassword2));
            },
            child: Container(
              margin: EdgeInsets.fromLTRB(16.h, 10.h, 20.h, 10.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgEye,
                height: 20.h,
                width: 24.h,
                fit: BoxFit.contain,
              ),
            ),
          ),
          suffixConstraints: BoxConstraints(
            maxHeight: 40.h,
          ),
          obscureText: state.isShowPassword2,
          contentPadding: EdgeInsets.fromLTRB(12.h, 10.h, 20.h, 10.h),
          borderDecoration: TextFormFieldStyleHelper.fillDeepOrangeTL18,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildColumnconfirmne(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 2.h),
            child: Text(
              "msg_confirm_new_password".tr,
              style: CustomTextStyles.titleSmallPrimaryContainer,
            ),
          ),
          SizedBox(height: 2.h),
          _buildConfirmNewPasswordSection(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildChangePasswordButton(BuildContext context) {
    return CustomElevatedButton(
      text: "lbl_change_password".tr,
      margin: EdgeInsets.only(
        left: 52.h,
        right: 58.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomNavigation(BuildContext context) {
    return Container(
      height: 40.h,
      padding: EdgeInsets.symmetric(horizontal: 58.h),
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22.h,
            margin: EdgeInsets.only(bottom: 12.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgHomePrimarycontainer,
                  height: 28.h,
                  width: double.maxFinite,
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgLine3,
                  height: 1.h,
                  width: double.maxFinite,
                )
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgMegaphone,
            height: 18.h,
            width: 20.h,
            margin: EdgeInsets.only(top: 4.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgCart,
            height: 22.h,
            width: 22.h,
            margin: EdgeInsets.only(top: 2.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgThumbsUp,
            height: 18.h,
            width: 26.h,
            margin: EdgeInsets.only(top: 4.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgVector,
            height: 20.h,
            width: 16.h,
            margin: EdgeInsets.only(top: 2.h),
          )
        ],
      ),
    );
  }

  /// Navigates to the previous screen.
  onTapArrowleftone(BuildContext context) {
    NavigatorService.goBack();
  }
}
