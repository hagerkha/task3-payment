import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [b_password_setting_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class BPasswordSettingModel extends Equatable {
  BPasswordSettingModel();

  BPasswordSettingModel copyWith() {
    return BPasswordSettingModel();
  }

  @override
  List<Object?> get props => [];
}
