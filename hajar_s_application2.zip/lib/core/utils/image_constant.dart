// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// 10.5.3 - B - Payment Method images
  static String imgGrid = '$imagePath/img_grid.svg';

  static String imgGroup8 = '$imagePath/img_group_8.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgHome = '$imagePath/img_home.svg';

  static String imgLock = '$imagePath/img_lock.svg';

// 10.5.5 - B - Password Setting images
  static String imgEye = '$imagePath/img_eye.svg';

  static String imgHomePrimarycontainer =
      '$imagePath/img_home_primarycontainer.svg';

  static String imgVector = '$imagePath/img_vector.svg';

// Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgMegaphone = '$imagePath/img_megaphone.svg';

  static String imgCart = '$imagePath/img_cart.svg';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgLine3 = '$imagePath/img_line_3.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
