final Map<String, String> enUs = {
  // 10.5.3 - B - Payment Method Screen
  "lbl_0000": "0000",
  "lbl_000_000_000_00": "000 000 000 00",
  "lbl_000_000_000_67": "000 000 000 67",
  "lbl_04_28": "04/28",
  "lbl_add_card": "Add Card",
  "lbl_card_number": "Card Number",
  "lbl_cvv": "CVV",
  "lbl_expiry_date": "Expiry date",
  "lbl_kathryn_murphy": "Kathryn Murphy",
  "lbl_save_card": "Save Card",
  "msg_card_holder_name": "Card holder name",

  // 10.5.5 - B - Password Setting Screen
  "lbl_change_password": "Change Password",
  "lbl_new_password": "New Password",
  "msg_confirm_new_password": "Confirm New Password",
  "msg_current_password": "Current Password",
  "msg_forgot_password": "Forgot Password?",
  "msg_password_settings": "Password Settings",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
