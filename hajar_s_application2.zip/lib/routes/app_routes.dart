import 'package:flutter/material.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/b_password_setting_screen/b_password_setting_screen.dart';
import '../presentation/b_payment_method_screen/b_payment_method_screen.dart';

class AppRoutes {
  static const String bPaymentMethodScreen = '/b_payment_method_screen';

  static const String bPasswordSettingScreen = '/b_password_setting_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        bPaymentMethodScreen: BPaymentMethodScreen.builder,
        bPasswordSettingScreen: BPasswordSettingScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: BPaymentMethodScreen.builder
      };
}
